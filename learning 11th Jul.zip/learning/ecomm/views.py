from django.shortcuts import render
from django.http import HttpResponse

from django.shortcuts import render_to_response 


# Create your views here.

def index(request):
    return render_to_response("ecomm/index.html")

def home(request):
    return HttpResponse("welcome to django world... Name : <input type='text' />")

    