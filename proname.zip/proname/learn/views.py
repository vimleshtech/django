from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render_to_response

# Create your views here.

def index(request):
    #return HttpResponse("hi ...")
    return render_to_response("learn/index.html")

def login(request):
    return render_to_response("learn/login.html")


def save(request):

    un = ''
    email = ''
    if request.method == 'GET':
        un  = request.GET['name']
        email  = request.GET['email']
        pwd  = request.GET['password']
        
        f = open('data.txt','a')
        f.write(un+'|'+email+'|'+pwd)
        f.close()

    #return HttpResponse("routed.."+un+' | '+email)
    return render_to_response("learn/login.html")

def validate(request):
    pwd = ''
    email = ''
    if request.method == 'GET':
        email  = request.GET['email']
        pwd  = request.GET['password']
    
    if email=='abcd@gmail.com' and pwd=='test':
        return render_to_response("learn/home.html")
    else:
        return HttpResponse('invalid user id and password')
    
