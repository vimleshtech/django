from django.conf.urls import url,include
from . import views


urlpatterns = [
    
  
    url('save',views.save,name="save"),
    url('login',views.login,name="login"),
    url('validate',views.validate,name="validate"),
    
    

    url('',views.index,name="index"), # 'url pattern',map function , name of response url
]
