from django.apps import AppConfig


class EcommConfig(AppConfig):
    name = 'ecomm'
